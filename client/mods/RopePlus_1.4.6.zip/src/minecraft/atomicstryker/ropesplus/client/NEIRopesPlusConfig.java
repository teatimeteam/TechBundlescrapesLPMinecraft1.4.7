package atomicstryker.ropesplus.client;

import net.minecraft.item.Item;
import atomicstryker.ropesplus.common.RopesPlusCore;
import atomicstryker.ropesplus.common.arrows.ItemArrow303;
import codechicken.nei.MultiItemRange;
import codechicken.nei.api.API;
import codechicken.nei.api.IConfigureNEI;

public class NEIRopesPlusConfig implements IConfigureNEI
{

    @Override
    public void loadConfig()
    {
        try
        {
            addSubSet();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    private void addSubSet()
    {
        MultiItemRange subTypes = new MultiItemRange();
        
        subTypes.add(RopesPlusCore.itemGrapplingHook);
        subTypes.add(RopesPlusCore.itemHookShot);
        subTypes.add(RopesPlusCore.itemHookShotCartridge);
        subTypes.add(RopesPlusCore.blockZipLineAnchor);
        subTypes.add(Item.bow);
        for (ItemArrow303 arrow : RopesPlusCore.arrowItems)
        {
            subTypes.add(arrow);
        }
        API.addSetRange("RopesPlus", subTypes);
    }

    @Override
    public String getName()
    {
        return "RopesPlus";
    }

    @Override
    public String getVersion()
    {
        return "1.0.0";
    }

}