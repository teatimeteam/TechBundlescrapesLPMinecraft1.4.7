package atomicstryker.ropesplus.common;

import net.minecraft.item.Item;

public class ItemRope extends Item
{
    public ItemRope(int i)
    {
        super(i);
        this.setTextureFile("/atomicstryker/ropesplus/client/ropesPlusItems.png");
    }
}
